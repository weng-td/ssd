import{j as o}from"./singletons.f084d2f0.js";const e=o("goto");export{e as g};
